package com.gautam.medicinetime;


public interface BasePresenter {

    void start();
}
