package com.gautam.medicinetime;


public interface BaseView<T> {

    void setPresenter(T presenter);
}
